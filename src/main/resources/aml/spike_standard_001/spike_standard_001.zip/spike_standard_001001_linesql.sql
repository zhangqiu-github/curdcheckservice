﻿delete from Aml_Const where ConstNum = 'sys_998';
delete from Aml_Const_Detail where ConstNum = 'sys_998';
insert into Aml_Const select 'sys_998','初始密码强制修改标识';
insert into Aml_Const_Detail select NEWID(),'sys_update_password','2','sys_998','系统初始化密码强制修改标识(1：强制；2：不强制)';